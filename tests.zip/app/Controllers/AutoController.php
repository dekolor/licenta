<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\AutoModel;

class AutoController extends Controller
{
    public function index()
    {
        $automodel = new AutoModel();
        $session = session();
        $data = [
            'username' => $session->get('name'),
            'autos' => $automodel->findAll()
        ];
        echo view('header2');
        echo view('nav2', $data);
        echo view('autolist', $data);
        echo view('footer2');
    }
}
