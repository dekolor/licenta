<?php
namespace App\Controllers;
use App\Models\AutoModel;
use App\Models\DeviceModel;
use App\Models\LogsModel;
use CodeIgniter\Controller;

class CronController extends Controller
{
    public function run()
    {
        $automodel = new AutoModel();
        $autos = $automodel->findAll();
        foreach ($autos as $auto)
        {
            $time_trigger = date('H:i', strtotime($auto['time_trigger']));
//            echo $time_trigger;
//            echo "<br>";
//            echo date('H:i');
//            echo "<br>";
//            echo date_default_timezone_get();
            $devices = json_decode($auto['devices'], TRUE);
//            print_r($devices);
            if($auto['zilnic']) {
                //ruleaza zilnic, verificam doar ora
                if($time_trigger == date('H:i')) {
                    //run auto
                    foreach($devices as $device) {
                        echo "E TIMPUL!!!";
                        file_get_contents('https://aws.dekolor.ro:8443/set/' . $device['deviceid'] . '/' . $device['setting']);
                        $devicemodel = new DeviceModel();
//                        $logsmodel = new LogsModel();
//                        $data = [
//                            'device' => $device['devicename'],
//                        ];
//                        $devicemodel->where('deviceid', $device['deviceid'])->set('status', $device['setting']== 'on' ? 1 : 0)->update();
//                        if($device['setting']=='on')
//                        {
//                            $data['action'] = "turnon";
//                            $data['message'] = "Device-ul \"" . $device['devicename'] . "\" a fost pornit.";
//                        } elseif($device['setting']=='off')
//                        {
//                            $data['action'] = "turnoff";
//                            $data['message'] = "Device-ul \"" . $device['devicename'] . "\" a fost oprit.";
//                        }
//                        echo "<pre>";
//                        print_r($data);
//                        echo "</pre>";
//                        $logsmodel->insert($data);
//                        $logsmodel->
                        $data = [];
                    }
                }
            }
        }
    }
}