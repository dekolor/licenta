<?php
namespace App\Controllers;

use App\Models\DeviceModel;

class DeviceController extends BaseController
{
    public function index()
    {
        /* ewelink stuff */

//        $devicedata = json_decode(file_get_contents("https://aws.dekolor.ro:8443"), TRUE);

        $devicemodel = new DeviceModel();
        $devicedata = $devicemodel->findAll();

        $session = session();
        $data = [
            'username' => $session->get('name'),
            'devices' => $devicedata,
        ];

        echo view('header2');
        echo view('nav2', $data);
        echo view('devicelist');
        echo view('footer2');
    }

    public function toggle($device)
    {
        $session = session();

        if($session->get('email')=="stefan@dekolor.ro") {
            $response = json_decode(file_get_contents("https://aws.dekolor.ro:8443/toggle/" . $device));
            sleep(1);
        }

        return redirect()->to('/devices');
    }
}