<div class="container">
    <h3>Device list:</h3>
    <!--<pre>-->
    <!--    --><?php
    //    print_r($devices);
    //    ?>
    <!--</pre>-->
    <?php
    foreach ($devices as $device) {
            ?><a href="<?php echo base_url('/toggledevice/' . $device['deviceid']); ?>">
            <div class="card <?php if ($device['status'] == 0) {
                //echo 'text-bg-danger';
            } ?>">
                <div class="card-body">
                    <?php echo $device['name']; ?>

                    <div style="float: right;">
                    <img width="40" src="<?php echo $device['brandlogo']; ?>" />

                    <?php if ($device['status']==0) { ?>
                        <span class="tag tag-orange">Off</span>
                    <?php } elseif ($device['status']==1) {
                        ?>
                        <span class="tag tag-green">On</span>
            <?php
                    } ?>
                    </div>
                </div>
            </div>
            </a>
            <?php
    }
    ?>
</div>
