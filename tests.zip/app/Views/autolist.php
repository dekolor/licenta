<div class="container">
    <h3>Automatizari:</h3>

    <table class="table">
        <thead>
            <tr>
                <th>Ora</th>
                <th>Zilnic?</th>
                <th>Actiuni</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($autos as $auto) {
            $deviceuri = json_decode(strval($auto['devices']), TRUE); ?>
            <tr>
                <td><?php echo $auto['time_trigger']; ?></td>
                <td><?php echo $auto['zilnic']==1 ? 'Da' : 'Nu'; ?></td>
                <td><?php foreach($deviceuri as $device) { echo $device['setting']=="on" ? "<span class=\"badge bg-success\">" : "<span class=\"badge bg-danger\">"; echo  $device['setting']=="on" ? 'Porneste ' : 'Opreste '; echo $device['devicename'] . "</span> "; } ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>