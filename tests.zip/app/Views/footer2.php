

<!-- JQUERY JS -->
<script src="https://dekolor.ro/assets/js/jquery.min.js"></script>

<!-- BOOTSTRAP JS -->
<script src="https://dekolor.ro/assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="https://dekolor.ro/assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<!-- SHOW PASSWORD JS -->
<script src="https://dekolor.ro/assets/js/show-password.min.js"></script>

<!-- GENERATE OTP JS -->
<script src="https://dekolor.ro/assets/js/generate-otp.js"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="https://dekolor.ro/assets/plugins/p-scroll/perfect-scrollbar.js"></script>

<!-- Color Theme js -->
<script src="https://dekolor.ro/assets/js/themeColors.js"></script>

<!-- CUSTOM JS -->
<script src="https://dekolor.ro/assets/js/custom.js"></script>

<!-- SIDEBAR JS -->
<script src="https://dekolor.ro/assets/plugins/sidebar/sidebar.js"></script>

<script src="https://dekolor.ro/assets/plugins/sidemenu/sidemenu.js"></script>

</body>

</html>